'use strict';
// ====== CONFIGURACIÓN (edita aquí) ======
const WHATSAPP = '50600000000'; // tu número con código de país, sin + ni espacios
const MONEDA = '₡';
const ENVIO = { domicilio: 3000, nacional: 5500, retiro: 0 };
const ENVIO_GRATIS_DESDE = 60000;
const PERFILES = {
  familiar:   { nombre: 'Familiar',      desc: 'Compro para mi ser querido. Precio regular.', desc_pct: 0 },
  cuidador:   { nombre: 'Cuidador/a',    desc: 'Trabajo cuidando adultos mayores. 8% de descuento.', desc_pct: 8 },
  terapeuta:  { nombre: 'Terapeuta',     desc: 'Profesional de salud o terapia ocupacional. 12% de descuento.', desc_pct: 12 },
  mayorista:  { nombre: 'Centro o mayorista', desc: 'Hogares, centros diurnos o reventa. 25% de descuento desde 10 unidades por producto.', desc_pct: 25, minimo: 10 }
};
const PRODUCTOS = [
  { id: 1, nombre: 'Kit de texturas', cat: 'Táctil', ico: '🧶', precio: 14500, desc: 'Ocho telas lavables con distintas texturas para explorar con las manos.' },
  { id: 2, nombre: 'Manta de actividades', cat: 'Táctil', ico: '🧣', precio: 28000, desc: 'Manta con cierres, botones, lazos y bolsillos para mantener las manos ocupadas.' },
  { id: 3, nombre: 'Muñeco de peso suave', cat: 'Relajación', ico: '🧸', precio: 19500, desc: 'Peluche lavable con peso moderado que transmite calma y compañía.' },
  { id: 4, nombre: 'Caja de recuerdos', cat: 'Memoria', ico: '📦', precio: 24000, desc: 'Objetos de oficios y épocas pasadas para conversar y recordar.' },
  { id: 5, nombre: 'Rompecabezas grandes', cat: 'Memoria', ico: '🧩', precio: 12500, desc: 'Piezas grandes con imágenes familiares, de 12 y 24 piezas.' },
  { id: 6, nombre: 'Pelotas de masaje', cat: 'Relajación', ico: '🟡', precio: 8500, desc: 'Set de tres pelotas con distintas durezas para ejercitar las manos.' },
  { id: 7, nombre: 'Tablero de cordones', cat: 'Motricidad', ico: '🪢', precio: 16500, desc: 'Madera y cordones de colores para practicar enhebrado y nudos.' },
  { id: 8, nombre: 'Kit de aromas', cat: 'Relajación', ico: '🌿', precio: 15000, desc: 'Seis saquitos con aromas naturales conocidos: lavanda, café, canela y más.' }
];
// ========================================
const $ = s => document.querySelector(s);
const fmt = n => MONEDA + Math.round(n).toLocaleString('es-CR');
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

let carrito = load('tactos_carrito', {});   // { id: cantidad }
let perfil = load('tactos_perfil', 'familiar');
let filtro = 'Todos';

function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2200); }

// ----- precios -----
function precioUnit(p, cant) {
  const pf = PERFILES[perfil];
  if (pf.minimo && cant < pf.minimo) return p.precio;
  return p.precio * (1 - pf.desc_pct / 100);
}
function calcular(entrega = 'domicilio') {
  let sub = 0, bruto = 0;
  Object.entries(carrito).forEach(([id, c]) => {
    const p = PRODUCTOS.find(x => x.id == id);
    bruto += p.precio * c; sub += precioUnit(p, c) * c;
  });
  const envio = !sub ? 0 : sub >= ENVIO_GRATIS_DESDE ? 0 : ENVIO[entrega];
  return { bruto, sub, desc: bruto - sub, envio, total: sub + envio };
}

// ----- catálogo -----
function pintarFiltros() {
  const cats = ['Todos', ...new Set(PRODUCTOS.map(p => p.cat))];
  $('#filtros').innerHTML = cats.map(c => `<button aria-pressed="${c === filtro}" data-cat="${c}">${c}</button>`).join('');
}
function pintarProductos() {
  const pf = PERFILES[perfil];
  $('#notaPrecio').textContent = pf.minimo
    ? `Perfil ${pf.nombre}: ${pf.desc_pct}% de descuento al comprar ${pf.minimo} o más unidades del mismo producto.`
    : `Perfil ${pf.nombre}${pf.desc_pct ? ': ' + pf.desc_pct + '% de descuento en todos los productos.' : ': precio regular.'}`;
  $('#productos').innerHTML = PRODUCTOS.filter(p => filtro === 'Todos' || p.cat === filtro).map(p => {
    const u = precioUnit(p, pf.minimo || 1);
    return `<article class="card"><div class="ico" aria-hidden="true">${p.ico}</div><h3>${p.nombre}</h3><p>${p.desc}</p>
    <div class="precio">${fmt(pf.minimo ? p.precio : u)}${pf.minimo ? `<small>${fmt(u)} c/u desde ${pf.minimo} unid.</small>` : pf.desc_pct ? `<small>Precio regular ${fmt(p.precio)}</small>` : ''}</div>
    <button class="btn" data-add="${p.id}">Agregar al carrito</button></article>`;
  }).join('');
}

// ----- carrito -----
function pintarCarrito() {
  const ids = Object.keys(carrito);
  $('#contador').textContent = Object.values(carrito).reduce((a, b) => a + b, 0);
  $('#items').innerHTML = ids.length ? ids.map(id => {
    const p = PRODUCTOS.find(x => x.id == id), c = carrito[id];
    return `<div class="item"><div><b>${p.ico} ${p.nombre}</b><br><small>${fmt(precioUnit(p, c))} c/u</small></div>
    <div class="qty"><button data-menos="${id}" aria-label="Quitar uno">−</button><span>${c}</span><button data-mas="${id}" aria-label="Agregar uno">+</button></div></div>`;
  }).join('') : '<p>Tu carrito está vacío. Agrega productos desde el catálogo.</p>';
  const t = calcular('retiro');
  $('#totales').innerHTML = ids.length ? `<div><span>Subtotal</span><span>${fmt(t.bruto)}</span></div>
    ${t.desc ? `<div><span>Descuento ${PERFILES[perfil].nombre}</span><span>−${fmt(t.desc)}</span></div>` : ''}
    <div class="t"><span>Total sin envío</span><span>${fmt(t.sub)}</span></div>
    <p class="aviso">Envío gratis desde ${fmt(ENVIO_GRATIS_DESDE)}.</p>` : '';
  $('#btnPagar').disabled = !ids.length;
  save('tactos_carrito', carrito);
}
function cambiar(id, d) {
  carrito[id] = (carrito[id] || 0) + d;
  if (carrito[id] <= 0) delete carrito[id];
  pintarCarrito();
}

// ----- perfiles -----
function pintarPerfiles() {
  $('#perfiles').innerHTML = Object.entries(PERFILES).map(([k, p]) =>
    `<button class="perfil" data-perfil="${k}" aria-pressed="${k === perfil}"><b>${p.nombre}</b>${p.desc}</button>`).join('');
  $('#perfilActual').textContent = PERFILES[perfil].nombre;
}

// ----- pago -----
const INFO_PAGO = {
  tarjeta: '<p class="aviso">Al confirmar te enviaremos un enlace de pago seguro. Para pagos en línea reales conecta tu pasarela (por ejemplo, Tilopay, Stripe o PayPal).</p>',
  sinpe: '<p class="aviso">Haz el SINPE Móvil al <b>0000-0000</b> a nombre de Tactos y envía el comprobante por WhatsApp.</p>',
  transferencia: '<p class="aviso">Transferencia a la cuenta IBAN <b>CR00 0000 0000 0000 0000 00</b>. Envía el comprobante por WhatsApp.</p>',
  contra: '<p class="aviso">Pagas en efectivo o SINPE al recibir. Disponible solo para entregas a domicilio.</p>'
};
function actualizarPago() {
  const e = $('#selEntrega').value;
  const sel = $('#selPago');
  sel.querySelector('[value=contra]').disabled = e !== 'domicilio';
  if (sel.value === 'contra' && e !== 'domicilio') sel.value = 'tarjeta';
  $('#lblDir').hidden = e === 'retiro';
  $('#detallePago').innerHTML = INFO_PAGO[sel.value];
  const t = calcular(e);
  $('#resumenPago').innerHTML = `<div><span>Productos</span><span>${fmt(t.sub)}</span></div><div><span>Envío</span><span>${t.envio ? fmt(t.envio) : 'Gratis'}</span></div><div class="t"><span>Total</span><span>${fmt(t.total)}</span></div>`;
}

// ----- eventos -----
document.addEventListener('click', e => {
  const t = e.target;
  if (t.dataset.add) { cambiar(t.dataset.add, perfil === 'mayorista' ? 1 : 1); toast('Agregado al carrito'); }
  if (t.dataset.mas) cambiar(t.dataset.mas, 1);
  if (t.dataset.menos) cambiar(t.dataset.menos, -1);
  if (t.dataset.cat) { filtro = t.dataset.cat; pintarFiltros(); pintarProductos(); }
  if (t.dataset.perfil) { perfil = t.dataset.perfil; save('tactos_perfil', perfil); pintarPerfiles(); pintarProductos(); pintarCarrito(); }
  if (t.hasAttribute('data-close')) { t.closest('dialog')?.close(); if (t.closest('.drawer')) $('#drawer').hidden = true; }
});
$('#btnCarrito').onclick = () => { $('#drawer').hidden = false; };
$('#btnPerfil').onclick = () => $('#perfilDlg').showModal();
$('#btnPagar').onclick = () => { $('#drawer').hidden = true; actualizarPago(); $('#pagoDlg').showModal(); };
$('#selEntrega').onchange = $('#selPago').onchange = actualizarPago;

$('#formPago').onsubmit = ev => {
  ev.preventDefault();
  const f = Object.fromEntries(new FormData(ev.target));
  const t = calcular(f.entrega);
  const lineas = Object.entries(carrito).map(([id, c]) => { const p = PRODUCTOS.find(x => x.id == id); return `• ${c} x ${p.nombre}`; }).join('\n');
  const msg = `Hola Tactos, quiero hacer este pedido (perfil ${PERFILES[perfil].nombre}):\n${lineas}\n\nTotal: ${fmt(t.total)}\nEntrega: ${f.entrega}${f.dir ? ' - ' + f.dir : ''}\nPago: ${f.pago}\nNombre: ${f.nombre}\nTel: ${f.tel}\nCorreo: ${f.mail}`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, '_blank');
  carrito = {}; pintarCarrito(); $('#pagoDlg').close(); ev.target.reset(); toast('¡Pedido enviado! Te confirmaremos por WhatsApp.');
};
$('#formCustom').onsubmit = ev => {
  ev.preventDefault();
  const f = Object.fromEntries(new FormData(ev.target));
  const msg = `Hola Tactos, quiero un kit personalizado.\nContacto: ${f.nombre} (${f.tel})\nEdad: ${f.edad || 'N/D'}\nNecesidad: ${f.necesidad}\nDetalles: ${f.detalle || 'N/D'}`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, '_blank');
  ev.target.reset();
};

pintarFiltros(); pintarPerfiles(); pintarProductos(); pintarCarrito();
